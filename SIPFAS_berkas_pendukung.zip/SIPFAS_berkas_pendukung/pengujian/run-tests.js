// Pengujian skenario SIPFAS dengan Playwright (Chromium headless).
// Jalankan: node run-tests.js <path index.html> <folder screenshot>
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const URL = 'file://' + path.resolve(process.argv[2]);
const SHOT = path.resolve(process.argv[3]);
fs.mkdirSync(SHOT, { recursive: true });
const hasil = [];
const catat = (id, req, skenario, harap, aktual, lulus) => {
  hasil.push({ id, req, skenario, harap, aktual, status: lulus ? 'Lulus' : 'Gagal' });
  console.log(`${id} [${lulus ? 'LULUS' : 'GAGAL'}] ${aktual}`);
};

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1.5, locale: 'id-ID', timezoneId: 'Asia/Jakarta' });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  const shot = (n, full = false) => page.screenshot({ path: `${SHOT}/${n}.png`, fullPage: full });
  const db = () => page.evaluate(() => JSON.parse(localStorage.getItem('sipfas_v5')));
  const PW = { 'raka@telkomuniversity.ac.id':'raka2026','nisa@telkomuniversity.ac.id':'nisa2026','admin.sipfas@telkomuniversity.ac.id':'admin2026','joko@telkomuniversity.ac.id':'joko2026','bagus@telkomuniversity.ac.id':'bagus2026','kepala.sipfas@telkomuniversity.ac.id':'kepala2026' };
  async function login(email, pass = PW[email]) {
    await page.goto(URL + '#');
    await page.evaluate(() => sessionStorage.clear());
    await page.goto(URL + '#'); await page.reload();
    await page.fill('#email', email); await page.fill('#pass', pass);
    await page.click('button[type=submit]');
  }

  // reset
  await page.goto(URL);
  await page.evaluate(() => { localStorage.clear(); sessionStorage.clear(); });
  await page.reload();
  await shot('01_login');

  // TC-01 login salah
  await login('raka@telkomuniversity.ac.id', 'salah123');
  const errTxt = await page.textContent('#login-error').catch(() => null);
  const sess = await page.evaluate(() => sessionStorage.getItem('sipfas_v5_sess'));
  await shot('02_login_gagal');
  catat('TC-01', 'FR-01', 'Login dengan kata sandi salah (raka@telkomuniversity.ac.id / salah123)',
    'Muncul pesan "Email atau kata sandi salah", sesi tidak terbentuk',
    `Pesan "${errTxt}" tampil; sesi = ${sess === null ? 'tidak ada' : sess}`, errTxt && sess === null);

  // TC-02 login benar
  await login('raka@telkomuniversity.ac.id');
  await page.waitForSelector('#list-saya');
  const navTxt = await page.textContent('#nav');
  await shot('03_pengaduan_saya');
  catat('TC-02', 'FR-01', 'Login pelapor dengan kredensial benar',
    'Masuk ke halaman Pengaduan Saya; menu hanya Buat Pengaduan & Pengaduan Saya',
    `Halaman Pengaduan Saya terbuka; menu: ${navTxt.replace(/\s+/g, ' ').trim()}`, /Pengaduan Saya/.test(navTxt) && !/Kelola/.test(navTxt));

  // TC-03 input tidak valid: kolom wajib kosong & deskripsi pendek
  await page.goto(URL + '#baru'); await page.waitForSelector('#fBaru');
  const n0 = (await db()).pengaduan.length;
  await page.fill('#judul', 'Lampu kelas mati');
  await page.fill('#deskripsi', 'Lampu mati');
  await page.click('#btnKirim');
  const errs = await page.$$eval('.err', e => e.map(x => x.textContent));
  const n1 = (await db()).pengaduan.length;
  await shot('04_validasi_form', true);
  catat('TC-03', 'FR-03', 'Kirim pengaduan dengan kategori & lokasi kosong, deskripsi "Lampu mati" (10 karakter)',
    'Pengaduan ditolak, pesan kesalahan per kolom, data tidak tersimpan',
    `${errs.length} pesan kesalahan tampil (${errs.join('; ')}); jumlah data tetap ${n1}`, errs.length === 3 && n0 === n1);

  // TC-04 foto terlalu besar
  await page.selectOption('#kategori', 'K02'); await page.selectOption('#lokasi', 'L04');
  await page.fill('#deskripsi', 'Dua lampu TL di barisan tengah lab B-102 padam sejak pagi.');
  await page.setInputFiles('#foto', { name: 'lampu_b102.jpg', mimeType: 'image/jpeg', buffer: Buffer.alloc(3 * 1024 * 1024, 1) });
  await page.click('#btnKirim');
  const fotoErr = await page.textContent('[data-err-for=foto]').catch(() => null);
  const n2 = (await db()).pengaduan.length;
  catat('TC-04', 'FR-03', 'Unggah foto JPG berukuran 3 MB',
    'Ditolak dengan pesan batas 2 MB, data tidak tersimpan', `Pesan: "${fotoErr}"; jumlah data tetap ${n2}`, !!fotoErr && n2 === n0);

  // TC-05 pdf
  await page.setInputFiles('#foto', { name: 'bukti.pdf', mimeType: 'application/pdf', buffer: Buffer.alloc(50 * 1024, 1) });
  await page.click('#btnKirim');
  const fmtErr = await page.textContent('[data-err-for=foto]').catch(() => null);
  catat('TC-05', 'FR-03', 'Unggah lampiran berformat PDF', 'Ditolak: format harus JPG/PNG', `Pesan: "${fmtErr}"`, /JPG atau PNG/.test(fmtErr || ''));

  // TC-06 deteksi duplikat
  await page.selectOption('#kategori', 'K01'); await page.selectOption('#lokasi', 'L02');
  const dup = await page.textContent('#dup-warning').catch(() => null);
  await shot('05_peringatan_duplikat');
  catat('TC-06', 'FR-10', 'Memilih kategori AC dan lokasi A-301 yang sudah punya pengaduan terbuka',
    'Muncul peringatan beserta nomor tiket pengaduan terbuka', dup ? `Peringatan tampil: "${dup.replace(/\s+/g, ' ').trim().slice(0, 90)}…"` : 'Tidak ada peringatan', !!dup && /PGD-2026-0001/.test(dup));

  // TC-07 pengaduan valid
  await page.selectOption('#kategori', 'K02'); await page.selectOption('#lokasi', 'L04');
  await page.fill('#judul', 'Lampu lab B-102 padam');
  await page.setInputFiles('#foto', { name: 'lampu_b102.jpg', mimeType: 'image/jpeg', buffer: Buffer.alloc(420 * 1024, 1) });
  await shot('06_form_terisi', true);
  await page.click('#btnKirim');
  await page.waitForSelector('#sukses-kirim');
  const ok = await page.textContent('#sukses-kirim');
  const d1 = await db(); const baru = d1.pengaduan[d1.pengaduan.length - 1];
  await shot('07_kirim_berhasil', true);
  catat('TC-07', 'FR-02', 'Kirim pengaduan lengkap: Listrik, B-102, deskripsi 58 karakter, foto JPG 420 KB',
    'Tersimpan dengan nomor tiket unik dan status Diajukan', `Tiket ${baru.no_tiket} tersimpan, status "${baru.status}", pesan sukses tampil`,
    /PGD-2026-0007/.test(ok) && baru.status === 'Diajukan');

  // TC-08 RBAC pelapor buka halaman admin
  await page.goto(URL + '#kelola'); await page.waitForSelector('#akses-ditolak');
  await shot('08_akses_ditolak');
  const ad1 = await page.isVisible('#akses-ditolak');
  // pelapor buka pengaduan milik orang lain (P0002 milik Nisa)
  await page.goto(URL + '#detail-P0002'); await page.waitForSelector('#akses-ditolak');
  const ad2 = await page.isVisible('#akses-ditolak');
  catat('TC-08', 'NFR-01', 'Pelapor (Raka) membuka URL #kelola dan detail pengaduan milik pelapor lain (P0002)',
    'Kedua akses ditolak', `#kelola: ${ad1 ? 'ditolak' : 'terbuka'}; #detail-P0002: ${ad2 ? 'ditolak' : 'terbuka'}`, ad1 && ad2);

  // TC-09 admin verifikasi tanpa prioritas -> error, lalu tugaskan
  await login('admin.sipfas@telkomuniversity.ac.id');
  await page.waitForSelector('#list-kelola');
  await shot('09_kelola_admin');
  await page.goto(URL + '#detail-' + baru.id); await page.waitForSelector('#aksi-admin');
  await page.click('#btnTugaskan');
  const e9 = await page.$$eval('.err', e => e.length);
  await page.selectOption('#prioritas', 'Tinggi'); await page.selectOption('#teknisi', 'U04');
  await page.fill('#catatan', 'Lab dipakai praktikum siang ini, mohon segera.');
  await shot('10_verifikasi_admin', true);
  await page.click('#btnTugaskan');
  const d2 = await db(); const p2 = d2.pengaduan.find(p => p.id === baru.id);
  catat('TC-09', 'FR-05', 'Admin menekan "Verifikasi & Tugaskan" tanpa prioritas/teknisi, lalu mengisi Tinggi + Joko',
    'Percobaan pertama ditolak; percobaan kedua status Ditugaskan', `Percobaan 1: ${e9} pesan kesalahan; percobaan 2: status "${p2.status}", prioritas ${p2.prioritas}, teknisi ${p2.id_teknisi}`,
    e9 === 2 && p2.status === 'Ditugaskan' && p2.id_teknisi === 'U04');

  // TC-10 tolak tanpa alasan, lalu dengan alasan (P0004 Diajukan)
  await page.goto(URL + '#detail-P0004'); await page.waitForSelector('#aksi-admin');
  await page.click('#btnTolak');
  const e10 = await page.textContent('#aksi-error').catch(() => null);
  const st10a = (await db()).pengaduan.find(p => p.id === 'P0004').status;
  await page.fill('#catatan', 'Laporan ganda, sudah ditangani pada tiket lain.');
  await page.click('#btnTolak');
  const st10b = (await db()).pengaduan.find(p => p.id === 'P0004').status;
  catat('TC-10', 'FR-05', 'Admin menolak P0004 tanpa alasan, lalu dengan alasan',
    'Tanpa alasan ditolak sistem; dengan alasan status Ditolak dan alasan tercatat', `Tanpa alasan: "${e10}", status tetap ${st10a}; dengan alasan: status ${st10b}`,
    !!e10 && st10a === 'Diajukan' && st10b === 'Ditolak');

  // TC-11 teknisi
  await login('joko@telkomuniversity.ac.id');
  await page.waitForSelector('h1');
  await shot('11_tugas_teknisi');
  await page.goto(URL + '#detail-' + baru.id); await page.click('#btnMulai');
  await page.click('#btnSelesai');
  const e11 = await page.textContent('#aksi-error').catch(() => null);
  await page.fill('#catatan', 'Starter dan ballast dua lampu TL diganti, lampu menyala normal.');
  await shot('12_laporan_teknisi', true);
  await page.click('#btnSelesai');
  const p11 = (await db()).pengaduan.find(p => p.id === baru.id);
  catat('TC-11', 'FR-06', 'Teknisi mulai mengerjakan, lalu menandai selesai tanpa catatan, kemudian dengan catatan',
    'Tanpa catatan ditolak; dengan catatan status Selesai', `Tanpa catatan: "${e11}"; dengan catatan: status ${p11.status}`, !!e11 && p11.status === 'Selesai');

  // TC-12 pelapor buka ulang lalu tutup
  await login('raka@telkomuniversity.ac.id');
  await page.goto(URL + '#notifikasi'); await page.waitForSelector('#list-notif');
  const notifN = await page.$$eval('#list-notif a', a => a.length);
  await shot('13_notifikasi');
  await page.goto(URL + '#detail-' + baru.id); await page.waitForSelector('#aksi-pelapor');
  await shot('14_konfirmasi_pelapor', true);
  await page.fill('#catatan', 'Satu lampu di dekat pintu masih berkedip.');
  await page.click('#btnBuka');
  const p12 = (await db()).pengaduan.find(p => p.id === baru.id);
  catat('TC-12', 'FR-07', 'Pelapor memilih "Belum Beres, Buka Ulang" dengan alasan lampu masih berkedip',
    'Status Dibuka Ulang; teknisi menerima notifikasi', `Status ${p12.status}; notifikasi teknisi: ${(await db()).notif.filter(n => n.untuk === 'U04' && /ulang/.test(n.pesan)).length}`,
    p12.status === 'Dibuka Ulang');

  await login('joko@telkomuniversity.ac.id');
  await page.goto(URL + '#detail-' + baru.id); await page.click('#btnMulai');
  await page.fill('#catatan', 'Lampu dekat pintu diganti tabung baru, tidak berkedip lagi.'); await page.click('#btnSelesai');
  await login('raka@telkomuniversity.ac.id');
  await page.goto(URL + '#detail-' + baru.id); await page.waitForSelector('#aksi-pelapor');
  await page.click('#btnTutup');
  const e13 = await page.textContent('#aksi-error').catch(() => null);
  await page.click('#stars button[data-v="4"]'); await page.click('#btnTutup');
  const d13 = await db(); const p13 = d13.pengaduan.find(p => p.id === baru.id);
  const jejak = d13.riwayat.filter(r => r.id_pengaduan === baru.id).map(r => r.status);
  await shot('15_riwayat_lengkap', true);
  catat('TC-13', 'FR-07, FR-08', 'Setelah perbaikan ulang, pelapor menutup tanpa rating, lalu dengan rating 4',
    'Tanpa rating ditolak; dengan rating status Ditutup dan seluruh perubahan tercatat di riwayat',
    `Tanpa rating: "${e13}"; status ${p13.status}, rating ${p13.rating}; riwayat ${jejak.length} entri (${jejak.join(' → ')})`,
    !!e13 && p13.status === 'Ditutup' && jejak.length === 8);

  // TC-14 rekap
  await login('kepala.sipfas@telkomuniversity.ac.id');
  await page.waitForSelector('#rekap-stats');
  const total = await page.textContent('#s-total');
  const d14 = await db();
  await shot('16_rekap', true);
  const rTerbuka = await page.textContent('#s-terbuka');
  const hitTerbuka = d14.pengaduan.filter(p => ['Diajukan', 'Ditugaskan', 'Dikerjakan', 'Dibuka Ulang'].includes(p.status)).length;
  catat('TC-14', 'FR-09', 'Kepala Sarpras membuka Rekap Layanan', 'Angka rekap sama dengan data tersimpan',
    `Total tampil ${total} (data ${d14.pengaduan.length}); belum selesai tampil ${rTerbuka} (data ${hitTerbuka})`, +total === d14.pengaduan.length && +rTerbuka === hitTerbuka);
  // kepala tidak bisa verifikasi
  await page.goto(URL + '#kelola'); const ad14 = await page.isVisible('#akses-ditolak').catch(() => false);
  catat('TC-15', 'NFR-01', 'Kepala Sarpras membuka halaman Kelola Pengaduan (khusus admin)', 'Akses ditolak', ad14 ? 'Akses ditolak' : 'Halaman terbuka', ad14);

  // TC-16 kinerja 500 data
  await login('admin.sipfas@telkomuniversity.ac.id');
  await page.evaluate(() => window.__seedBanyak(500));
  const waktu = [];
  for (let i = 0; i < 20; i++) {
    const t0 = Date.now();
    await page.goto(URL + '#kelola'); await page.reload(); await page.waitForSelector('#list-kelola tbody tr');
    waktu.push(Date.now() - t0);
  }
  waktu.sort((a, b) => a - b);
  const p95 = waktu[Math.ceil(0.95 * waktu.length) - 1];
  const nBaris = await page.$$eval('#list-kelola tbody tr', r => r.length);
  catat('TC-16', 'NFR-02', `Muat halaman Kelola Pengaduan berisi ${nBaris} data, diulang 20 kali`, 'P95 waktu tampil ≤ 3 detik',
    `P95 = ${(p95 / 1000).toFixed(2).replace('.', ',')} detik (min ${waktu[0]} ms, maks ${waktu[waktu.length - 1]} ms)`, p95 <= 3000);

  // TC-17 responsif 360px
  await page.evaluate(() => { localStorage.removeItem('sipfas_v5'); });
  await page.reload();
  const mob = await browser.newContext({ viewport: { width: 360, height: 740 }, deviceScaleFactor: 2, locale: 'id-ID', isMobile: true, hasTouch: true });
  const mp = await mob.newPage();
  await mp.goto(URL + '#');
  await mp.fill('#email', 'nisa@telkomuniversity.ac.id'); await mp.fill('#pass', 'nisa2026'); await mp.click('button[type=submit]');
  await mp.goto(URL + '#baru'); await mp.waitForSelector('#fBaru');
  const over = await mp.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  await mp.screenshot({ path: `${SHOT}/17_mobile_form.png`, fullPage: true });
  await mp.goto(URL + '#saya'); await mp.waitForSelector('#list-saya');
  await mp.screenshot({ path: `${SHOT}/18_mobile_list.png` });
  catat('TC-17', 'NFR-04', 'Membuka form pengaduan pada layar lebar 360 px', 'Tidak ada geser horizontal; semua kolom terlihat',
    `Selisih lebar konten = ${over} px`, over <= 0);


  // TC-18..20 pendaftaran akun (FR-12)
  await page.goto(URL + '#'); await page.evaluate(() => sessionStorage.clear()); await page.reload();
  await page.click('#link-daftar'); await page.waitForSelector('#fDaftar');
  const u0 = (await db()).users.length;
  await page.fill('#d-nama', 'Nadia Putri');
  await page.fill('#d-email', 'nadia.putri@gmail.com');
  await page.fill('#d-nomor', '1030623');
  await page.fill('#d-pass', 'nadia2026'); await page.fill('#d-pass2', 'nadia2027');
  await page.click('#btnDaftar');
  const e18 = await page.$$eval('.err', e => e.map(x => x.textContent));
  const u1 = (await db()).users.length;
  await shot('19_daftar_validasi', true);
  catat('TC-18', 'FR-12', 'Daftar dengan email gmail.com, status kosong, NIM 7 digit, ulangan sandi berbeda',
    'Pendaftaran ditolak dengan pesan per kolom, akun tidak dibuat', `${e18.length} pesan kesalahan (${e18.join('; ')}); jumlah akun tetap ${u1}`, e18.length === 4 && u0 === u1);
  await page.fill('#d-email', 'raka@telkomuniversity.ac.id'); await page.selectOption('#d-status', 'Mahasiswa');
  await page.fill('#d-nomor', '103062300099'); await page.fill('#d-pass2', 'nadia2026');
  await page.click('#btnDaftar');
  const e19 = await page.textContent('[data-err-for=d-email]').catch(() => null);
  const u2 = (await db()).users.length;
  catat('TC-19', 'FR-12', 'Daftar dengan email yang sudah terdaftar (raka@telkomuniversity.ac.id)', 'Ditolak, akun tidak ganda', `Pesan: "${e19}"; jumlah akun tetap ${u2}`, /sudah terdaftar/.test(e19 || '') && u2 === u0);
  await page.fill('#d-email', 'nadia.putri@telkomuniversity.ac.id');
  await shot('20_daftar_terisi', true);
  await page.click('#btnDaftar');
  await page.waitForSelector('#daftar-sukses');
  await shot('21_daftar_sukses');
  const nu = (await db()).users.find(u => u.email === 'nadia.putri@telkomuniversity.ac.id');
  await page.fill('#pass', 'nadia2026'); await page.click('button[type=submit]');
  await page.waitForSelector('#list-saya');
  const nav20 = await page.textContent('#nav');
  catat('TC-20', 'FR-12', 'Daftar dengan data valid (Nadia Putri, Mahasiswa, NIM 103062300099), lalu login dengan akun baru',
    'Akun tersimpan sebagai pelapor dan dapat langsung dipakai login', `Akun ${nu ? nu.id : '-'} tersimpan dengan peran ${nu ? nu.peran : '-'}; login berhasil ke Pengaduan Saya`, !!nu && nu.peran === 'pelapor' && /Pengaduan Saya/.test(nav20));

  // tangkapan layar notifikasi admin & kepala (data awal)
  await page.evaluate(() => localStorage.removeItem('sipfas_v5')); await page.reload();
  await login('admin.sipfas@telkomuniversity.ac.id'); await page.goto(URL + '#notifikasi'); await page.waitForSelector('#list-notif');
  await shot('22_notif_admin');
  await login('kepala.sipfas@telkomuniversity.ac.id'); await page.goto(URL + '#notifikasi'); await page.waitForSelector('#list-notif');
  await shot('23_notif_kepala');

  fs.writeFileSync(path.join(SHOT, 'hasil.json'), JSON.stringify({ waktu_uji: new Date().toISOString(), browser: 'Chromium ' + browser.version(), hasil, js_errors: errors }, null, 2));
  console.log('JS errors:', errors);
  await browser.close();
})();
